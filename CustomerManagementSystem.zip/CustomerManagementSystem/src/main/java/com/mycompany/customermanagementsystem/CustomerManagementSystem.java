/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.customermanagementsystem;

/**
 *
 * @author PTHOMPSO
 */
public class CustomerManagementSystem {

    public static void main(String[] args) {
        new LoginForm();
    }
}
